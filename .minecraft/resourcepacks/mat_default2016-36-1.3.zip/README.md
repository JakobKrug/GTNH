[![Download](https://img.shields.io/badge/-soundpack%20download-brightgreen)](https://github.com/makamys/MAtmos-2016-Default/releases)

# MAtmos default soundpack 2016
The original MAtmos soundpack from 2012, updated to work on the latest versions of MAtmos.

Requires MAtmos 36 or higher as of 1.3.

The Git repository only tracks the code; the sound files can be found in the releases.

## Demo video
[![](http://img.youtube.com/vi/Z4Zu4kvyDHU/0.jpg)](http://www.youtube.com/watch?v=Z4Zu4kvyDHU "")

# License
The soundpack's code is licensed under WTFPLv2.
